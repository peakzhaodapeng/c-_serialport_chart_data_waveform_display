﻿namespace MonitorandDebug
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.label1 = new System.Windows.Forms.Label();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.front_angle_textBox1 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.portnum_comboBox1 = new System.Windows.Forms.ComboBox();
            this.portNUM = new System.Windows.Forms.Label();
            this.baudrate = new System.Windows.Forms.Label();
            this.baudrate_comboBox = new System.Windows.Forms.ComboBox();
            this.databits = new System.Windows.Forms.Label();
            this.databits_comboBox3 = new System.Windows.Forms.ComboBox();
            this.stopbits = new System.Windows.Forms.Label();
            this.stopbits_comboBox4 = new System.Windows.Forms.ComboBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.open_serialport_btn = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "font wheel angle";
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // front_angle_textBox1
            // 
            this.front_angle_textBox1.Location = new System.Drawing.Point(20, 48);
            this.front_angle_textBox1.Name = "front_angle_textBox1";
            this.front_angle_textBox1.Size = new System.Drawing.Size(100, 21);
            this.front_angle_textBox1.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.front_angle_textBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(45, 17);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(215, 89);
            this.panel1.TabIndex = 9;
            // 
            // chart1
            // 
            chartArea4.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea4);
            legend4.Name = "Legend1";
            this.chart1.Legends.Add(legend4);
            this.chart1.Location = new System.Drawing.Point(290, 17);
            this.chart1.Name = "chart1";
            series4.ChartArea = "ChartArea1";
            series4.Legend = "Legend1";
            series4.Name = "Series1";
            this.chart1.Series.Add(series4);
            this.chart1.Size = new System.Drawing.Size(704, 437);
            this.chart1.TabIndex = 17;
            this.chart1.Text = "chart1";
            // 
            // portnum_comboBox1
            // 
            this.portnum_comboBox1.FormattingEnabled = true;
            this.portnum_comboBox1.Location = new System.Drawing.Point(20, 34);
            this.portnum_comboBox1.Name = "portnum_comboBox1";
            this.portnum_comboBox1.Size = new System.Drawing.Size(114, 20);
            this.portnum_comboBox1.TabIndex = 25;
            // 
            // portNUM
            // 
            this.portNUM.AutoSize = true;
            this.portNUM.Location = new System.Drawing.Point(19, 16);
            this.portNUM.Name = "portNUM";
            this.portNUM.Size = new System.Drawing.Size(47, 12);
            this.portNUM.TabIndex = 26;
            this.portNUM.Text = "portNUM";
            // 
            // baudrate
            // 
            this.baudrate.AutoSize = true;
            this.baudrate.Location = new System.Drawing.Point(20, 72);
            this.baudrate.Name = "baudrate";
            this.baudrate.Size = new System.Drawing.Size(53, 12);
            this.baudrate.TabIndex = 28;
            this.baudrate.Text = "baudrate";
            // 
            // baudrate_comboBox
            // 
            this.baudrate_comboBox.FormattingEnabled = true;
            this.baudrate_comboBox.Location = new System.Drawing.Point(20, 90);
            this.baudrate_comboBox.Name = "baudrate_comboBox";
            this.baudrate_comboBox.Size = new System.Drawing.Size(114, 20);
            this.baudrate_comboBox.TabIndex = 27;
            // 
            // databits
            // 
            this.databits.AutoSize = true;
            this.databits.Location = new System.Drawing.Point(20, 125);
            this.databits.Name = "databits";
            this.databits.Size = new System.Drawing.Size(53, 12);
            this.databits.TabIndex = 30;
            this.databits.Text = "databits";
            // 
            // databits_comboBox3
            // 
            this.databits_comboBox3.FormattingEnabled = true;
            this.databits_comboBox3.Location = new System.Drawing.Point(20, 143);
            this.databits_comboBox3.Name = "databits_comboBox3";
            this.databits_comboBox3.Size = new System.Drawing.Size(114, 20);
            this.databits_comboBox3.TabIndex = 29;
            // 
            // stopbits
            // 
            this.stopbits.AutoSize = true;
            this.stopbits.Location = new System.Drawing.Point(20, 190);
            this.stopbits.Name = "stopbits";
            this.stopbits.Size = new System.Drawing.Size(53, 12);
            this.stopbits.TabIndex = 32;
            this.stopbits.Text = "stopbits";
            // 
            // stopbits_comboBox4
            // 
            this.stopbits_comboBox4.FormattingEnabled = true;
            this.stopbits_comboBox4.Location = new System.Drawing.Point(20, 208);
            this.stopbits_comboBox4.Name = "stopbits_comboBox4";
            this.stopbits_comboBox4.Size = new System.Drawing.Size(114, 20);
            this.stopbits_comboBox4.TabIndex = 31;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel4.Controls.Add(this.open_serialport_btn);
            this.panel4.Controls.Add(this.stopbits);
            this.panel4.Controls.Add(this.stopbits_comboBox4);
            this.panel4.Controls.Add(this.databits);
            this.panel4.Controls.Add(this.databits_comboBox3);
            this.panel4.Controls.Add(this.baudrate);
            this.panel4.Controls.Add(this.baudrate_comboBox);
            this.panel4.Controls.Add(this.portNUM);
            this.panel4.Controls.Add(this.portnum_comboBox1);
            this.panel4.Location = new System.Drawing.Point(45, 133);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(215, 321);
            this.panel4.TabIndex = 33;
            // 
            // open_serialport_btn
            // 
            this.open_serialport_btn.Location = new System.Drawing.Point(20, 249);
            this.open_serialport_btn.Name = "open_serialport_btn";
            this.open_serialport_btn.Size = new System.Drawing.Size(113, 34);
            this.open_serialport_btn.TabIndex = 33;
            this.open_serialport_btn.Text = "open";
            this.open_serialport_btn.UseVisualStyleBackColor = true;
            this.open_serialport_btn.Click += new System.EventHandler(this.open_serialport_btn_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 50;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1054, 487);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Monitor&Debug Terminal";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.TextBox front_angle_textBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.ComboBox portnum_comboBox1;
        private System.Windows.Forms.Label portNUM;
        private System.Windows.Forms.Label baudrate;
        private System.Windows.Forms.ComboBox baudrate_comboBox;
        private System.Windows.Forms.Label databits;
        private System.Windows.Forms.ComboBox databits_comboBox3;
        private System.Windows.Forms.Label stopbits;
        private System.Windows.Forms.ComboBox stopbits_comboBox4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button open_serialport_btn;
        private System.Windows.Forms.Timer timer1;
    }
}

