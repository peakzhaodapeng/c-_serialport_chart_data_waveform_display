﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;//得有这个文件才能支持串口
using System.Windows.Forms.DataVisualization.Charting;//需要增加一个头文件

namespace MonitorandDebug
{
    
    public partial class Form1 : Form
    {
        public static Byte[] datafresh = new Byte[4];//定义一个四个字节的数组，为了能让所有的函数都能使用，前面加了public和static，而且这也是一个实例
        private SerialPort serialPort;
        public Form1()
        {
            serialPort = new SerialPort();
            InitializeComponent();


            Series series = chart1.Series[0];
            // 画样条曲线（Spline）
            series.ChartType = SeriesChartType.Spline;
            // 线宽2个像素
            series.BorderWidth = 2;
            // 线的颜色：红色
            series.Color = System.Drawing.Color.Red;
            // 图示上的文字            
            series.IsVisibleInLegend = false;   //隐藏图示上的文字          
            // 设置显示范围
            ChartArea chartArea = chart1.ChartAreas[0];

            chartArea.AxisX.Minimum = 1;
            chartArea.AxisX.Maximum = 101;//这个值支持双精度浮点数，肯定支持负数和小数了

            chartArea.AxisY.Minimum = -2.5d;
            chartArea.AxisY.Maximum = 92.5d;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            System.Windows.Forms.Control.CheckForIllegalCrossThreadCalls = false;//禁用了所有的控件合法性检查
            

            baudrate_comboBox.Items.Add(115200);
            baudrate_comboBox.Text = baudrate_comboBox.Items[0].ToString();//波特率默认值

            databits_comboBox3.Items.Add(8);
            databits_comboBox3.Text = databits_comboBox3.Items[0].ToString();//数据位默认值肯定是数组第一个元素了

            stopbits_comboBox4.Items.Add(1);
            stopbits_comboBox4.Text = stopbits_comboBox4.Items[0].ToString();
            
            string[] ArrComPortsName = SerialPort.GetPortNames();//获取当前串口个数名称
            if (ArrComPortsName.Length != 0)
            {
                Array.Sort(ArrComPortsName);
            }
            for (int portNUM_cnt = 0; portNUM_cnt < ArrComPortsName.Length; portNUM_cnt++)
            {
                portnum_comboBox1.Items.Add(ArrComPortsName[portNUM_cnt]);
            }
            portnum_comboBox1.Text = ArrComPortsName[0];

        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
             
            try
            {

                //* Byte数组的个数是不确定的，根据实时返回的指令个数为准,而且返回的都是10进制数
                do
                {
                    //serialPort.ReadBufferSize();
                      int count = serialPort.BytesToRead;  // 串口的接收缓冲区，
                    if (count <= 0)   //count <= 0 ：表示没有接收到指令
                        break;
                     Byte[] dataBuff = new Byte[count];

                     if (count == 8)//加了一个保护再也不会出问题了，不到8个字节直接不处理，这样就避免了 datafresh[inter_cnt] = dataBuff[inter_cnt + 2];读数据的时候数组里面就没这么多
                     {
                         serialPort.Read(dataBuff, 0, count);  //串口读取接收缓存区的数据


                         for (int inter_cnt = 0; inter_cnt < 4; inter_cnt++)
                         {
                             datafresh[inter_cnt] = dataBuff[inter_cnt + 2];//如果这一句加上就会出错误：未将对象引用设置到对象的实例
                         }

                         front_angle_textBox1.Text = BitConverter.ToSingle(dataBuff, 2).ToString();//对于dataBuff数组从第二个数组开始检索。
                     }
                   
                   // serialPort.DiscardInBuffer();//丢弃串口缓冲区中的内容
                } while (serialPort.BytesToRead >0);//这里仅仅是保证>0就可以，但是我需要的可是八个字节

            }
            catch (Exception ex)
            {
                MessageBox.Show("error:接收返回信息异常：" + ex.Message);
            }      
        }

        private void open_serialport_btn_Click(object sender, EventArgs e)
        {
            try
            {
                serialPort.PortName = portnum_comboBox1.Text;
                serialPort.BaudRate = Convert.ToInt32(baudrate_comboBox.Text);  //转换为10进制
                serialPort.DataBits = Convert.ToInt16(databits_comboBox3.Text);
                serialPort.StopBits = (StopBits)Enum.Parse(typeof(StopBits), stopbits_comboBox4.Text);
                serialPort.Open();

                serialPort.ReceivedBytesThreshold = 8; //获取或设置 System.IO.Ports.SerialPort.DataReceived 事件发生前内部输入缓冲区中的字节数，达到这个字节数会触发中断。
                serialPort.DataReceived += new SerialDataReceivedEventHandler(serialPort1_DataReceived); //串口接收指令事件

                open_serialport_btn.Enabled = false;  //打开按钮不可用         

            }
            catch
            {
                MessageBox.Show("串口设置错误");
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Draw(); 
        }
        Queue<float> Q1 = new Queue<float>();
        
        public void Draw()
        {
            this.chart1.Series[0].Points.Clear();

            Q1.Enqueue(BitConverter.ToSingle(datafresh, 0));//对于datafresh数组，肯定得从0开始检索，float占四个字节，低字节地址小
            if (Q1.Count > 100)
                Q1.Dequeue();
            for (int i = 0; i < Q1.Count; i++)
            {
                chart1.Series[0].Points.AddY(Q1.ElementAt(i));
            }
        }

    }
}
